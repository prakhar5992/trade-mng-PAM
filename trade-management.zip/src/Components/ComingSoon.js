import React, { Component } from 'react';

function ComingSoon(){
    return(
        <div>
            <h3>Comming Soon</h3>
        </div>
    );
}

export default ComingSoon;